package com.interfaces;

public interface DataService {
	int[] getListOfNumbers();
}
