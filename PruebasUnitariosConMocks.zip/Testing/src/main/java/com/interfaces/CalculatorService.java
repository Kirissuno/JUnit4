package com.interfaces;

public interface CalculatorService {
	double calculateAverage();
}
